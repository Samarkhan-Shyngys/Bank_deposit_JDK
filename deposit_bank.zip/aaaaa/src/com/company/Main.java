package com.company;

public class Main {

    public static void main(String[] args) {
        //HalykBank hbank = new HalykBank();
        //System.out.println(hbank.getName() + " " + hbank.name);

        Client client = new Client();
        client.WelcomeClient();
	// write your code here
    }
}
