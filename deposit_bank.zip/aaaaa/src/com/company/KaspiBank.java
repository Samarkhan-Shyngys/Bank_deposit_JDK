package com.company;

public class KaspiBank extends Banks {
    public KaspiBank(){
        procent = 15;
        name = "Kaspi Bank";
    }
}
