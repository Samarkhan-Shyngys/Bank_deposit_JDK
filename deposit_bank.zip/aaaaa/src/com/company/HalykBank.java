package com.company;

public class HalykBank extends Banks{

    public HalykBank(){
        procent = 12;
        name = "Halyk Bank";
    }
};